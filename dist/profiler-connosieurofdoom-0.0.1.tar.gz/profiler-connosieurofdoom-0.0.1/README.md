# profiler
Repository with code for profiling other functions.

pip install -i https://test.pypi.org/simple/ connosieurofdoom==0.0.1

Prints the CPU and memory usage